<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 33b028d720bc9a470f93024ecdb3035d

$pluginsetting = array (
);
?>