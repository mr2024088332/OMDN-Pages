<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['member']['conisbind']) { ?>
<p class="pbm bbda xi1">您已将本站帐号 <strong><?php echo $_G['member']['username'];?></strong> 与QQ号码绑定</p>
<br />

<?php if($_G['member']['conisregister']) { ?>
<h2>
<a href="home.php?mod=spacecp&amp;ac=profile&amp;op=password" class="xi2">为单独登录站点创建登录密码</a>
</h2>
<br />
<?php } ?>

<h2>
<a href="javascript:;" onclick="display('unbind');<?php if($_G['member']['conisregister']) { ?>$('newpassword1').focus();<?php } ?>" class="xi2">解除已绑定帐号？</a>
</h2>

<?php if($_G['member']['conisregister']) { ?>
<div id="unbind" style="display:none;">
<form action="connect.php?mod=config" method="post" autocomplete="off">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
<div class="ptm pbm">
<p>您当前是使用QQ帐号绑定到 <?php echo $_G['setting']['bbname'];?></p>
<p>为了您可以继续使用本站帐号 <strong><?php echo $_G['member']['username'];?></strong>，请设置本站登录密码</p>
</div>
<div class="password">
<table cellspacing="0" cellpadding="0" class="tfm">
<tr>
<th>新密码</th>
<td><input type="password" size="25" name="newpassword1" id="newpassword1" class="px" value="" /><em class="d">登录本站使用</em></td>
</tr>
<tr>
<th>确认密码</th>
<td><input type="password" size="25" name="newpassword2" id="newpassword2" class="px" value="" /></td>
</tr>
<tr>
<th></th>
<td>
<input type="hidden" name="op" value="unbind"/>
<button type="submit" name="connectsubmit" value="yes" class="pn pnc"><strong>确认解除</strong></button>
</td>
</tr>
</table>
</div>
</form>
</div>
<?php } else { ?>
<div id="unbind" style="display:none;">
<form action="connect.php?mod=config" method="post" autocomplete="off">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
<p class="mtm mbm">
您确认要解除与本站帐号的绑定关系？
</p>
<div>
<input type="hidden" name="op" value="unbind"/>
<button type="submit" name="connectsubmit" value="yes" class="pn pnc"><strong>确认解除</strong></button>
</div>
</form>
</div>
<?php } } else { ?>
<div class="mtw bm2 cl">
<div class="bm2_b bw0 hm" style="padding-top: 70px;">
<a href="<?php echo $_G['connect']['loginbind_url'];?>"><img src="<?php echo IMGDIR;?>/qq_bind.gif" /></a>
<p class="mtn xg1">点击按钮，立刻绑定QQ帐号</p>
</div>
<div class="bm2_b bm2_b_y bw0">
<dl class="xld">
<h2 class="xi1 xs2">使用QQ帐号绑定本站，您可以...</h2>
<dt>用QQ帐号轻松登录</dt>
<dd class="xg1">无需记住本站的帐号和密码，随时使用QQ帐号密码轻松登录</dd>
<dt>把本站精彩内容分享到QQ空间和腾讯朋友</dt>
<dd class="xg1">每一个精彩内容绝不放过，简单快捷的将论坛主题分享给好友和听众</dd>
</dl>
</div>
</div>
<?php } ?>