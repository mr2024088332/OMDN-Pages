<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('usertag');?><?php include template('common/header'); ?><h3 class="flb">
<em><?php if($_G['thread']['special'] == 4) { ?>给活动参与者贴标签<?php } elseif($_G['thread']['special'] == 1) { ?>给参与投票的会员贴标签<?php } else { ?>给参与回帖的会员贴标签<?php } ?></em>
</h3>
<form id="usertagform" method="post" autocomplete="off" action="forum.php?mod=misc&amp;action=usertag&amp;addusertag=yes&amp;infloat=yes" onsubmit="ajaxpost('usertagform', 'return_<?php echo $_GET['handlekey'];?>', '', '');return false;">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
<input type="hidden" name="tid" value="<?php echo $_G['tid'];?>" />
<input type="hidden" name="handlekey" value="<?php echo $_GET['handlekey'];?>" />
<div class="c bart">
<p>
<input type="text" name="tags" id="tags" class="px vm" value="" size="60" />
<img src="<?php echo IMGDIR;?>/faq.gif" alt="Tip" class="vm" tip="用逗号或空格隔开多个标签，最多可填写 5 个" onmouseover="showTip(this)" />
</p>
<?php if($polloptions) { ?>
<p class="mtn">选择相应的投票项：(列出了有投票的选项,可多选,不选表示给所有投票用户加标签)</p>
<p>
<select multiple="multiple" name="polloptions" style="width:331px" size="5"><?php if(is_array($polloptions)) foreach($polloptions as $var) { ?><option value="<?php echo $var['polloptionid'];?>"><?php echo $var['polloption'];?></option>
<?php } ?>
</select>
</p><br>
<?php } if($recent_use_tag) { ?>
<p class="mtn">最近使用标签:<?php $tagi = 0;?><?php if(is_array($recent_use_tag)) foreach($recent_use_tag as $var) { if($tagi) { ?>, <?php } ?><a href="javascript:;" class="xi2" onclick="$('tags').value == '' ? $('tags').value = '<?php echo $var;?>' : $('tags').value += ',<?php echo $var;?>';"><?php echo $var;?></a><?php $tagi++;?><?php } ?>
</p>
<?php } if($lastlog) { ?>
<p class="mtn">添加标签记录:</p><?php if(is_array($lastlog)) foreach($lastlog as $log) { ?><p><?php echo $log['dateline'];?> <?php echo $log['username'];?> : <?php echo $log['reason'];?></p>
<?php } } ?>
</div>
<p class="o pns" id="return_<?php echo $_GET['handlekey'];?>">
<button type="submit" name="addusertag" class="pn" value="true"><strong>提交</strong></button>
<button type="button" id="closebtn" class="pn" onclick="hideWindow('<?php echo $_GET['handlekey'];?>');"><strong>关闭</strong></button>
</p>
</form>
<script type="text/javascript">
function errorhandle_<?php echo $_GET['handlekey'];?>(msg, values) {
var  msgmode = !values['haserror'] ? 'right' : 'alert';
if(values['limit']) {
var action = $('usertagform').getAttribute('action');
action = hostconvert(action);
$('usertagform').action = action.replace(/\&limit\=\d+/g, '')+'&limit='+values['next'];
$('return_<?php echo $_GET['handlekey'];?>').innerHTML = msg;
setTimeout("ajaxpost('usertagform', 'return_<?php echo $_GET['handlekey'];?>', '', '')", '1000');
return false;
}
showDialog(msg, msgmode, '', null, true, null, '', '', '', 3);
hideWindow('<?php echo $_GET['handlekey'];?>');
}
</script><?php include template('common/footer'); ?>